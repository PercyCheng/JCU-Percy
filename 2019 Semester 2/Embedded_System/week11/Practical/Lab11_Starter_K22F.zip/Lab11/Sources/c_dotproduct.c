#include "PE_Types.h"
#include "PE_Error.h"
#include "PE_Const.h"
#include "IO_Map.h"

unsigned int c_dotproduct(int Q, int len, unsigned int *vecA, unsigned int *vecB)
{
	/* write your code here */
	
	return 0;
}

